import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./FormIVRequest.css";

const FormIVRequest = () => {
    const [formData, setFormData] = useState({
        fullName: "",
        registrationNumber: "",
        sport: "",
        eventJoined: "",
        dateOfJoining: "",
        medicalFitness: false,
        medicalOfficerSignature: null,
        coachSignature: null,
        date: "",
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value, type, checked } = e.target;
        setFormData({
            ...formData,
            [name]: type === "checkbox" ? checked : value,
        });
    };

    const handleFileChange = (e, fieldName) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                setFormData({ ...formData, [fieldName]: reader.result });
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Form IV Request Submitted:", formData);
        alert("Form IV Request submitted successfully!");
    };

    return (
        <div className="form-container">
            <div className="top-red-block">
                <img src={require("../../assets/logos/yspa.jpg")} alt="YSPA Logo" className="yspa-logo" />
                <div className="yspa-text">
                    <h6 className="yspa-text">YOUTH & SPORTS PROMOTION</h6>
                    <h6 className="yspa-text">ASSOCIATION OF TAMILNADU</h6>
                </div>
            </div>
            <form onSubmit={handleSubmit}>
                <label>
                    Full Name of Player:
                    <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleChange}
                        required
                    />
                </label>
                <label>
                    Player Registration Number:
                    <input
                        type="text"
                        name="registrationNumber"
                        value={formData.registrationNumber}
                        onChange={handleChange}
                        required
                    />
                </label>
                <label>
                    Sport:
                    <input
                        type="text"
                        name="sport"
                        value={formData.sport}
                        onChange={handleChange}
                        required
                    />
                </label>
                <label>
                    Event/Camp/Team Joined:
                    <input
                        type="text"
                        name="eventJoined"
                        value={formData.eventJoined}
                        onChange={handleChange}
                        required
                    />
                </label>
                <label>
                    Date of Joining:
                    <input
                        type="date"
                        name="dateOfJoining"
                        value={formData.dateOfJoining}
                        onChange={handleChange}
                        required
                    />
                </label>
                <fieldset>
                    <legend>Medical Fitness Confirmation:</legend>
                    <label>
                        <input
                            type="checkbox"
                            name="medicalFitness"
                            checked={formData.medicalFitness}
                            onChange={handleChange}
                        />
                        Certified that the player is physically fit and has joined training on the specified date.
                    </label>
                </fieldset>
                <label>
                    Name & Signature of Medical Officer:
                    <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileChange(e, "medicalOfficerSignature")}
                    />
                </label>
                <label>
                    Name & Signature of Team Manager / Coach:
                    <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileChange(e, "coachSignature")}
                    />
                </label>
                <label>
                    Date:
                    <input
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleChange}
                        required
                    />
                </label>
                <div className="form-actions">
                    <button type="submit">Submit</button>
                    <button type="button" className="back-button" onClick={() => navigate("/feed")}>
                        Back
                    </button>
                </div>
            </form>
        </div>
    );
};

export default FormIVRequest;
