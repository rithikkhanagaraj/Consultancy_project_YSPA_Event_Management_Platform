import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import logo from "../../assets/logos/yspa.jpg";
import "./ComplaintForm.css";  // Import the CSS file

const ComplaintForm = () => {
    const [formData, setFormData] = useState({
        name: "",
        address: "",
        phone: "",
        complaint: ""
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Complaint Submitted:", formData);
        alert("Complaint Submitted Successfully!");
        setFormData({ name: "", address: "", phone: "", complaint: "" });
    };

    return (
        <>
            {/* Header */}
            <div className="top-header">
                <img
                    src={logo}
                    alt="Logo"
                    className="logo-img"
                />
                <div>
                    <h2 style={{ margin: 0, fontSize: "1.5rem" }}>
                        YOUTH & SPORTS PROMOTION ASSOCIATION
                    </h2>
                    <h6 style={{ margin: "5px 0 0", fontSize: "0.9rem" }}>
                        OF TAMILNADU
                    </h6>
                </div>
            </div>

            {/* Complaint Form */}
            <div className="form-wrapper">
                <form onSubmit={handleSubmit} className="form-layout">
                    <h2 className="form-heading">Complaint Form</h2>

                    <input
                        type="text"
                        name="name"
                        placeholder="Name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="text"
                        name="address"
                        placeholder="Address"
                        value={formData.address}
                        onChange={handleChange}
                        required
                    />
                    <input
                        type="tel"
                        name="phone"
                        placeholder="Phone Number"
                        value={formData.phone}
                        onChange={handleChange}
                        required
                    />
                    <textarea
                        name="complaint"
                        placeholder="Enter your complaint"
                        value={formData.complaint}
                        onChange={handleChange}
                        required
                    ></textarea>
                    <button type="submit" className="submit-btn">Submit</button>
                    
                    {/* Back Button */}
                    <button 
                        type="button" 
                        className="back-btn" 
                        onClick={() => navigate("/feed")}>
                        Back
                    </button>
                </form>
            </div>
        </>
    );
};

export default ComplaintForm;
