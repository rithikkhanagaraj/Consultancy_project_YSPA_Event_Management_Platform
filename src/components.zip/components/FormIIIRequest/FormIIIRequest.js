import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./FormIIIRequest.css";

const FormIIIRequest = () => {
    const [formData, setFormData] = useState({
        fullName: "",
        sport: "",
        registrationNumber: "",
        familyMembers: [{ name: "", age: "", relationship: "", residingWithPlayer: "", aadhaar: "" }],
        declaration: false,
        playerSignature: null,
        guardianSignature: null,
    });

    const navigate = useNavigate();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleFamilyMemberChange = (index, field, value) => {
        const updatedFamilyMembers = [...formData.familyMembers];
        updatedFamilyMembers[index][field] = value;
        setFormData({ ...formData, familyMembers: updatedFamilyMembers });
    };

    const addFamilyMember = () => {
        setFormData({
            ...formData,
            familyMembers: [...formData.familyMembers, { name: "", age: "", relationship: "", residingWithPlayer: "", aadhaar: "" }],
        });
    };

    const handleFileChange = (e, fieldName) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = () => {
                setFormData({ ...formData, [fieldName]: reader.result });
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log("Form Data:", formData);
        alert("Form III Request submitted successfully!");
    };

    return (
        <div className="form-container">
            <div className="top-red-block">
                <img src={require("../../assets/logos/yspa.jpg")} alt="YSPA Logo" className="yspa-logo" />
                <div className="yspa-text">
                    <h6 className="yspa-text">YOUTH & SPORTS PROMOTION</h6>
                    <h6 className="yspa-text">ASSOCIATION OF TAMILNADU</h6>
                </div>
            </div>
            <form onSubmit={handleSubmit}>
                <label>
                    Full Name of Player:
                    <input
                        type="text"
                        name="fullName"
                        value={formData.fullName}
                        onChange={handleInputChange}
                        required
                    />
                </label>
                <label>
                    Sport:
                    <input
                        type="text"
                        name="sport"
                        value={formData.sport}
                        onChange={handleInputChange}
                        required
                    />
                </label>
                <label>
                    Registration Number:
                    <input
                        type="text"
                        name="registrationNumber"
                        value={formData.registrationNumber}
                        onChange={handleInputChange}
                        required
                    />
                </label>
                <fieldset>
                    <legend>Family Members:</legend>
                    {formData.familyMembers.map((member, index) => (
                        <div key={index} className="family-member">
                            <label>
                                Name:
                                <input
                                    type="text"
                                    value={member.name}
                                    onChange={(e) => handleFamilyMemberChange(index, "name", e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                Age:
                                <input
                                    type="number"
                                    value={member.age}
                                    onChange={(e) => handleFamilyMemberChange(index, "age", e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                Relationship:
                                <input
                                    type="text"
                                    value={member.relationship}
                                    onChange={(e) => handleFamilyMemberChange(index, "relationship", e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                Whether residing with player (Yes/No):
                                <input
                                    type="text"
                                    value={member.residingWithPlayer}
                                    onChange={(e) => handleFamilyMemberChange(index, "residingWithPlayer", e.target.value)}
                                    required
                                />
                            </label>
                            <label>
                                Aadhaar No. / ID (optional):
                                <input
                                    type="text"
                                    value={member.aadhaar}
                                    onChange={(e) => handleFamilyMemberChange(index, "aadhaar", e.target.value)}
                                />
                            </label>
                        </div>
                    ))}
                    <button type="button" onClick={addFamilyMember}>
                        Add Family Member
                    </button>
                </fieldset>
                <fieldset>
                    <legend>Declaration:</legend>
                    <label>
                        <input
                            type="checkbox"
                            name="declaration"
                            checked={formData.declaration}
                            onChange={(e) => setFormData({ ...formData, declaration: e.target.checked })}
                            required
                        />
                        I hereby declare that the information provided is correct.
                    </label>
                </fieldset>
                <label>
                    Signature of Player:
                    <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileChange(e, "playerSignature")}
                        required
                    />
                </label>
                <label>
                    Signature of Parent/Guardian (if minor):
                    <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleFileChange(e, "guardianSignature")}
                    />
                </label>
                <div className="form-actions">
                    <button type="submit">Submit</button>
                    <button type="button" className="back-button" onClick={() => navigate("/feed")}>
                        Back
                    </button>
                </div>
            </form>
        </div>
    );
};

export default FormIIIRequest;
