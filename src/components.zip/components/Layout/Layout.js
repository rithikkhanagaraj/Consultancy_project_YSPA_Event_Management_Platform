import React from "react";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faHome, faCompass, faSignOutAlt } from "@fortawesome/free-solid-svg-icons"; // Added faSignOutAlt for Logout
import "./Layout.css";

const Layout = ({ children }) => {
    const navigate = useNavigate();

    const handleLogout = () => {
        navigate("/"); // Redirect to login page
    };

    return (
        <div className="layout-container">
            <div className="content">{children}</div>
            <div className="bottom-navbar">
                <div className="nav-item" onClick={() => navigate("/home")}>
                    <FontAwesomeIcon icon={faHome} size="lg" />
                    <span>Home</span>
                </div>
                <div className="nav-item" onClick={() => navigate("/feed")}>
                    <FontAwesomeIcon icon={faCompass} size="lg" />
                    <span>Explore</span>
                </div>
                <div className="nav-item" onClick={handleLogout}>
                    <FontAwesomeIcon icon={faSignOutAlt} size="lg" />
                    <span>Logout</span>
                </div>
            </div>
        </div>
    );
};

export default Layout;
