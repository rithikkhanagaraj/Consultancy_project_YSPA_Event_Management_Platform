import React, { useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import { v4 as uuidv4 } from "uuid"; // Import UUID for unique ID generation
import "./Payment.css";

import yspaLogo from "../../assets/logos/yspa.jpg";

const Payment = () => {
    const navigate = useNavigate(); // Initialize navigation
    const [isTeam, setIsTeam] = useState(false);
    const [teamMembers, setTeamMembers] = useState([""]);
    const [formData, setFormData] = useState({
        sportName: "",
        teamName: "",
        soloName: "",
        date: "",
        email: "",
    });

    const handleTeamMemberChange = (index, value) => {
        const updatedMembers = [...teamMembers];
        updatedMembers[index] = value;
        setTeamMembers(updatedMembers);
    };

    const addTeamMember = () => {
        setTeamMembers([...teamMembers, ""]);
    };

    const removeTeamMember = (index) => {
        const updatedMembers = teamMembers.filter((_, i) => i !== index);
        setTeamMembers(updatedMembers);
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const eventId = `EVT${Math.floor(1000 + Math.random() * 9000)}`; // Generate a simple event ID
        console.log("Form Data:", formData);
        console.log("Team Members:", teamMembers);

        // Navigate to the Ticket page with form data and event ID
        navigate("/ticket", {
            state: {
                eventId,
                formData,
                teamMembers: isTeam ? teamMembers : null,
                displayFor: ["User Purpose", "Administration Purpose"], // Include both purposes
            },
        });
    };

    return (
        <div className="payment-container">
            {/* Top Red Block */}
            <div className="top-red-block">
                <img src={yspaLogo} alt="YSPA Logo" className="yspa-logo" />
                <div className="yspa-text">
                    <h6 className="yspa-text">YOUTH & SPORTS PROMOTION</h6>
                    <h6 className="yspa-text">ASSOCIATION OF TAMILNADU</h6>
                </div>
            </div>

            {/* Payment Form */}
            <div className="payment-section">
                <h3>Complete Your Payment</h3>
                <form className="payment-form" onSubmit={handleSubmit}>
                    <label>
                        Name of the Sport:
                        <input
                            type="text"
                            name="sportName"
                            value={formData.sportName}
                            onChange={(e) => setFormData({ ...formData, sportName: e.target.value })}
                            placeholder="Enter sport name"
                            required
                        />
                    </label>
                    <div className="selection-buttons">
                        <button
                            type="button"
                            className={`selection-button ${!isTeam ? "active" : ""}`} // Add "active" class for Solo
                            onClick={() => setIsTeam(false)}
                        >
                            Solo
                        </button>
                        <button
                            type="button"
                            className={`selection-button ${isTeam ? "active" : ""}`} // Add "active" class for Team
                            onClick={() => setIsTeam(true)}
                        >
                            Team
                        </button>
                    </div>
                    
                    {isTeam ? (
                        <>
                            <label>
                                Team Name:
                                <input
                                    type="text"
                                    name="teamName"
                                    value={formData.teamName}
                                    onChange={(e) => setFormData({ ...formData, teamName: e.target.value })}
                                    placeholder="Enter team name"
                                    required
                                />
                            </label>
                            <div className="team-members">
                                <h4>Team Members:</h4>
                                {teamMembers.map((member, index) => (
                                    <div key={index} className="team-member-row">
                                        <input
                                            type="text"
                                            value={member}
                                            onChange={(e) =>
                                                handleTeamMemberChange(index, e.target.value)
                                            }
                                            placeholder={`Member ${index + 1}`}
                                            required
                                        />
                                        <button
                                            type="button"
                                            className="remove-member-button"
                                            onClick={() => removeTeamMember(index)}
                                        >
                                            -
                                        </button>
                                    </div>
                                ))}
                                <button
                                    type="button"
                                    className="add-member-button"
                                    onClick={addTeamMember}
                                >
                                    +
                                </button>
                            </div>
                        </>
                    ) : (
                        <label>
                            Name:
                            <input
                                type="text"
                                name="soloName"
                                value={formData.soloName}
                                onChange={(e) => setFormData({ ...formData, soloName: e.target.value })}
                                placeholder="Enter your name"
                                required
                            />
                        </label>
                    )}
                    <label>
                        Date:
                        <input
                            type="date"
                            name="date"
                            value={formData.date}
                            onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                            required
                        />
                    </label>
                    <label>
                        Email:
                        <input
                            type="email"
                            name="email"
                            value={formData.email}
                            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                            placeholder="Enter your email"
                            required
                        />
                    </label>
                    <button type="submit" className="pay-button">
                        Submit Form
                    </button>
                </form>
            </div>
        </div>
    );
};

export default Payment;
