import React, { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";
import { useLocation } from "react-router-dom";
import "./Home.css";
import yspaLogo from "../../assets/logos/yspa.jpg"; // YSPA logo

const supabaseUrl = "https://bjntxmsmpmbldbqsftof.supabase.co";
const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJqbnR4bXNtcG1ibGRicXNmdG9mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDM1MDQ1MjEsImV4cCI6MjA1OTA4MDUyMX0.t8Ig_iyBoWhRFDLROJcIRWvkT3J_SnrVuYKt5kDbg0s";
const supabase = createClient(supabaseUrl, supabaseKey);

const Home = () => {
  const [activeTab, setActiveTab] = useState("ongoing");
  const [events, setEvents] = useState([]);
  const [likedPosts, setLikedPosts] = useState({});
  const [showPaymentPrompt, setShowPaymentPrompt] = useState(false);
  const location = useLocation();

  useEffect(() => {
    fetchEvents();
    // Check if redirected from form submission
    const params = new URLSearchParams(location.search);
    if (params.get("formSubmitted") === "true") {
      setShowPaymentPrompt(true);
    }
  }, []);

  // Fetch events from Supabase
  const fetchEvents = async () => {
    const { data, error } = await supabase.from("events").select("*");
    if (error) {
      console.error("Error fetching events:", error.message);
    } else {
      setEvents(data);
    }
  };

  // Toggle like state for a post
  const handleLike = (postId) => {
    setLikedPosts((prev) => ({
      ...prev,
      [postId]: !prev[postId],
    }));
  };

  // Copy Google Form link to clipboard
  const copyLink = (googleFormLink) => {
    navigator.clipboard.writeText(googleFormLink).then(() => {
      alert("Link copied to clipboard!");
    });
  };

  // Animate posts on scroll into view
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("visible");
          } else {
            entry.target.classList.remove("visible");
          }
        });
      },
      { threshold: 0.1 }
    );
    const posts = document.querySelectorAll(".post");
    posts.forEach((post) => observer.observe(post));
    return () => {
      posts.forEach((post) => observer.unobserve(post));
    };
  }, [events, activeTab]);

  // Render event posts based on type
  const renderEvents = (type) =>
    events
      .filter((event) => event.eventType === type)
      .map((event) => (
        <div key={event.id} className="post">
          <img src={event.imageUrl} alt="Event" className="post-image" />
          <div className="post-actions">
            <button className="like-btn" onClick={() => handleLike(event.id)}>
              <img
                src={
                  likedPosts[event.id]
                    ? "https://cdn-icons-png.flaticon.com/128/833/833472.png"
                    : "https://cdn-icons-png.flaticon.com/128/1077/1077035.png"
                }
                alt="Like"
              />
            </button>
            <button className="share-btn" onClick={() => copyLink(event.googleFormLink)}>
              <img
                src="https://cdn-icons-png.flaticon.com/128/2099/2099085.png"
                alt="Share"
              />
            </button>
            <button
              className="register-btn"
              onClick={() => {
                window.open(event.googleFormLink, "_blank");
                window.location.href = "/home?formSubmitted=true"; // Redirect back to home with query param
              }}
            >
              Register
            </button>
          </div>
          <p className="post-description">{event.description}</p>
        </div>
      ));

  return (
    <div className="home-container">
      {/* Top Red Block */}
      <div className="top-red-block">
        <img src={yspaLogo} alt="YSPA Logo" className="yspa-logo" />
        <h6 className="yspa-text">YOUTH & SPORTS PROMOTION ASSOCIATION</h6>
      </div>

      {/* Tabs */}
      <div className="tabs-container">
        <button
          className={`tab ${activeTab === "ongoing" ? "active" : ""}`}
          onClick={() => setActiveTab("ongoing")}
        >
          Ongoing
        </button>
        <button
          className={`tab ${activeTab === "upcoming" ? "active" : ""}`}
          onClick={() => setActiveTab("upcoming")}
        >
          Upcoming
        </button>
      </div>

      {/* Event Posts */}
      {activeTab === "ongoing" && renderEvents("Ongoing")}
      {activeTab === "upcoming" && renderEvents("Upcoming")}

      {/* Payment Prompt */}
      {showPaymentPrompt && (
        <div className="popup">
          <h3>Form submitted successfully!</h3>
          <p>Do you want to proceed to payment?</p>
          <button
            className="proceed-btn"
            onClick={() => {
              setShowPaymentPrompt(false);
              window.location.href = "/payment"; // Navigate to payment page
            }}
          >
            Yes, Proceed
          </button>
          <button
            className="proceed-btn"
            onClick={() => setShowPaymentPrompt(false)} // Close the prompt
          >
            No, Cancel
          </button>
        </div>
      )}
    </div>
  );
};

export default Home;
