import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import logo from "../../assets/logos/yspa.jpg"; // Adjust if necessary
import "./JobApplication.css";

const JobApplication = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    resume: null,
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, files } = e.target;
    setFormData({
      ...formData,
      [name]: name === "resume" ? files[0] : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Job Application Submitted:", formData);
    alert("Job Application Submitted Successfully!");
    setFormData({
      name: "",
      email: "",
      phone: "",
      address: "",
      resume: null,
    });
  };

  return (
    <>
      {/* Header Block */}
      <div className="top-header">
        <img src={logo} alt="Logo" className="logo-img" />
        <div>
          <h2 className="header-title">YOUTH & SPORTS PROMOTION ASSOCIATION</h2>
          <h6 className="header-subtitle">OF TAMILNADU</h6>
        </div>
      </div>

      <div className="form-wrapper">
        <form onSubmit={handleSubmit} className="form-layout">
          <h2 className="form-heading">Job Application Form</h2>

          <input
            type="text"
            name="name"
            placeholder="Full Name"
            value={formData.name}
            onChange={handleChange}
            required
          />

          <input
            type="email"
            name="email"
            placeholder="Email Address"
            value={formData.email}
            onChange={handleChange}
            required
          />

          <input
            type="tel"
            name="phone"
            placeholder="Phone Number"
            value={formData.phone}
            onChange={handleChange}
            required
          />

          <textarea
            name="address"
            placeholder="Address"
            value={formData.address}
            onChange={handleChange}
            required
          ></textarea>

          {/* Resume Upload */}
          <label>
            <legend>Resume:</legend>
            <input
              type="file"
              name="resume"
              accept=".pdf,.doc,.docx"
              onChange={handleChange}
              required
            />
          </label>

          <button type="submit" className="submit-btn">Submit</button>
          <button type="button" className="back-btn" onClick={() => navigate("/feed")}>Back</button>
        </form>
      </div>
    </>
  );
};

export default JobApplication;
