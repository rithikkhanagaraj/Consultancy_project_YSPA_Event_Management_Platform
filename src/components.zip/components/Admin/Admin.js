import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import supabase from "../../supabaseClient"; // Use the shared Supabase client
import "./Admin.css";
import yspaLogo from '../../assets/logos/yspa.jpg';
import { FaSignOutAlt, FaPlusCircle, FaTasks, FaFileAlt, FaMoneyCheckAlt, FaWpforms, FaFileSignature } from "react-icons/fa";

const Admin = () => {
    const navigate = useNavigate();
    const [sportNames, setSportNames] = useState([]);
    const [showPopup, setShowPopup] = useState(false); // State to control popup visibility

    const handleLogout = () => {
        navigate("/"); // Redirect to login page
    };

    // Fetch unique sport names from the Payments table
    const fetchSportNames = async () => {
        try {
            const { data, error } = await supabase
                .from("Payments")
                .select("sport_name", { distinct: true }) // Use distinct to fetch unique sport names
                .neq("sport_name", null);

            if (error) {
                console.error("Error fetching sport names:", error.message);
            } else {
                setSportNames(data.map((item) => item.sport_name));
                setShowPopup(true); // Show popup when sports are fetched
            }
        } catch (err) {
            console.error("Unexpected error:", err);
        }
    };

    const closePopup = () => {
        setShowPopup(false); // Close the popup
    };

    return (
        <div className="admin-container">
            <div className="top-red-block">
                <img src={yspaLogo} alt="YSPA Logo" className="yspa-logo" />
                <div className="yspa-text">
                    <h6 className="yspa-text">YOUTH & SPORTS PROMOTION</h6>
                    <h6 className="yspa-text">ASSOCIATION OF TAMILNADU</h6>
                </div>
            </div>
            <div className="admin-grid">
                <div className="admin-card" onClick={handleLogout}>
                    <FaSignOutAlt className="admin-icon gradient-icon" />
                    <p className="gradient-text">Logout</p>
                </div>
                <div className="admin-card" onClick={() => navigate("/admin/create-event")}>
                    <FaPlusCircle className="admin-icon gradient-icon" />
                    <p className="gradient-text">Create New Event</p>
                </div>
                <div className="admin-card">
                    <FaTasks className="admin-icon gradient-icon" />
                    <p className="gradient-text">Manage Events</p>
                </div>
                <div className="admin-card" onClick={fetchSportNames}>
                    <FaFileAlt className="admin-icon gradient-icon" />
                    <p className="gradient-text">Responses</p>
                </div>
                <div className="admin-card" onClick={() => navigate("/admin/form-requests")}>
                    <FaWpforms className="admin-icon gradient-icon" />
                    <p className="gradient-text">Form Requests</p>
                </div>
                <div className="admin-card" onClick={() => navigate("/admin/form-ii-requests")}>
                    <FaFileSignature className="admin-icon gradient-icon" />
                    <p className="gradient-text">Form II Requests</p>
                </div>
            </div>

            {/* Popup for sport names */}
            {showPopup && (
                <div className="popup-overlay">
                    <div className="popup">
                        <h3>Available Sports</h3>
                        <ul>
                            {sportNames.map((sportName, index) => (
                                <li key={index}>
                                    <button
                                        className="sport-name-button"
                                        onClick={() => {
                                            navigate(`/admin/responses/${sportName}`);
                                            closePopup();
                                        }}
                                    >
                                        {sportName}
                                    </button>
                                </li>
                            ))}
                        </ul>
                        <button className="close-popup-button" onClick={closePopup}>
                            Close
                        </button>
                    </div>
                </div>
            )}
        </div>
    );
};

export default Admin;
