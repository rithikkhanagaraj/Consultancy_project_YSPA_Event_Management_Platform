import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import supabase from "../../supabaseClient"; // Use the shared Supabase client
import "./Responses.css"; // Import CSS for styling

const Responses = () => {
    const { sportName } = useParams(); // Get sport_name from the route parameters
    const [tickets, setTickets] = useState([]);
    const [searchTerm, setSearchTerm] = useState(""); // State for search input
    const [filteredTickets, setFilteredTickets] = useState([]); // State for filtered tickets

    // Fetch tickets based on the sport_name
    const fetchTickets = async () => {
        try {
            const { data, error } = await supabase
                .from("Payments")
                .select("*")
                .eq("sport_name", sportName);

            if (error) {
                console.error("Error fetching tickets:", error.message);
            } else {
                setTickets(data);
                setFilteredTickets(data); // Initialize filtered tickets
            }
        } catch (err) {
            console.error("Unexpected error:", err);
        }
    };

    // Filter tickets based on the search term
    const handleSearch = (e) => {
        const value = e.target.value;
        setSearchTerm(value);
        const filtered = tickets.filter((ticket) =>
            ticket.event_id.toLowerCase().includes(value.toLowerCase())
        );
        setFilteredTickets(filtered);
    };

    useEffect(() => {
        fetchTickets();
    }, [sportName]);

    return (
        <div className="responses-container">
            <h2 className="responses-title">Tickets for {sportName}</h2>
            <div className="search-bar">
                <input
                    type="text"
                    placeholder="Search by Event ID"
                    value={searchTerm}
                    onChange={handleSearch}
                />
            </div>
            <div className="responses-content">
                <table className="ticket-table">
                    <thead>
                        <tr>
                            <th>Event ID</th>
                            <th>Sport Name</th>
                            <th>Solo Name</th>
                            <th>Date</th>
                            <th>Email</th>
                            <th>Team Name</th>
                            <th>Team Members</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredTickets.map((ticket, index) => (
                            <tr key={index}>
                                <td>{ticket.event_id}</td>
                                <td>{ticket.sport_name}</td>
                                <td>{ticket.solo_name || "N/A"}</td>
                                <td>{ticket.date}</td>
                                <td>{ticket.email}</td>
                                <td>{ticket.team_name || "N/A"}</td>
                                <td>
                                    {ticket.team_members
                                        ? ticket.team_members.join(", ")
                                        : "N/A"}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default Responses;
